//: [Previous](@previous)

import Foundation

//MARK: Extension Challenges

//MARK: Second Challenge
//Extend the `Array` type to add a method `secondElement()` that returns the second element of the array if it exists, or `nil` if the array has fewer than two elements. Additionally, add a computed property `isNotEmpty` that returns `true` if the array is not empty, and `false` otherwise.

extension Array { func secondElement() -> Element? {
guard count >= 2 else { return nil }
return self[1]
    }

var isNotEmpty: Bool {
    return !isEmpty
    }

}

// Ejemplo de uso:
let numbers = [1, 2, 3, 4]

if let second = numbers.secondElement() {
print("The second element is \(second)")
} else {
print("The array does not have a second element")
}
// The second element is 2

let emptyArray: [Int] = []
print("Is the array not empty? \(emptyArray.isNotEmpty)")
// Is the array not empty? false



// MARK: Third Challenge
//Give the `Int` type a nested `enum` with cases **even** and **odd**.
//Also give `Int` a property of that type to correctly report whether an integer is even or odd.
//MARK: Fourth Challenge (optional)
//Update the `Int` a nested `enum` with cases **even** and **odd** to conform to `CustomStringConvertible` so it has a custom print description.
//Make the protocol conformance of the enum in an extension

extension Int{
    enum EvenOrOdd: CustomStringConvertible {
        var description: String{
            switch self {
            case.even: return "Hey, I'm an even number"
            case.odd: return "Oh no, I'm an odd number"
            }
        }
        case even
        case odd
        
    }
    var type: EvenOrOdd {
        return self % 2 == 0 ? .even : .odd
    }
}

let myInt = 2
print(myInt.type) // Hey, I'm an even number
print(7.type) // Hey, I'm an even number














//: [Next](@next)
