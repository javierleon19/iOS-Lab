import UIKit

//First Challenge
//The `printTable(_:)` function has a bug: It crashes if any of the data items are longer than the label of their column.

//Try changing the age of a person to _1,000_ to see this happen. Fix the bug.
//
//> [!NOTE]
//> Your solution will likely result in incorrect table formatting; that is fine for now. You will fix the formatting in the third challenge, below.

import Foundation


// MAP
// Filter
// Reduce


let myArray = [1, 2, 3, 4, 5, 6]

let transformedArray = myArray.map { "\($0)" }

//print(transformedArray)

let fileteredArray = myArray.filter { value in
    return value % 2 == 0
}

//print(fileteredArray)


// Protocolos

// Radio Protocol
// - changeVolume
// - changeSong
// - connectPhone

//let data = [
//    ["Eva", "30", "6"],
//    ["Salem", "40", "18"],
//    ["Andres", "50", "20"]
//]

//let headers = [
//    "Emplyee name",
//    "Age",
//    "Years of experience"
//]

protocol TabularDataSource {
    var numberOfRow: Int { get }
    var numberOfColumns: Int { get }
    
    func label(forColumn column: Int) -> String
    func itemForRow(row: Int, column: Int) -> String
}

struct Person {
    let name: String
    let age: Int
    let yearsOfExperience: Int
}

struct Department: TabularDataSource {
    var numberOfRow: Int { people.count }
    
    var numberOfColumns: Int { 3 }
    
    func label(forColumn column: Int) -> String {
        let label: String
        
        switch column {
        case 0: label = "Employee name"
        case 1: label = "Age"
        case 2: label = "Years of experience"
        default: fatalError("A department should only have 3 columns")
        }
        
        return label
    }
    
    func itemForRow(row: Int, column: Int) -> String {
        let person = people[row]
        let item: String
        
        switch column {
        case 0: item = person.name
        case 1: item = "🙊\(person.age)"
        case 2: item = "\(person.yearsOfExperience)"
        default: fatalError("Invalid row: \(row), column: \(column) combination")
        }
        
        return item
    }
    
    let name: String
    var people: [Person] = []
    init(name: String) {
        self.name = name
    }
    
    mutating func add(_ person: Person) {
        people.append(person)
    }
}

var department = Department(name: "Engineering")
department.add(Person(name: "Eva", age: 1000, yearsOfExperience: 6))
department.add(Person(name: "Salem", age: 40, yearsOfExperience: 8))
department.add(Person(name: "Andres", age: 50, yearsOfExperience: 10))

func printTable(_ dataSource: TabularDataSource) {
    var headerRow = "|"
    var columnWidths = [Int]()
    
    for columnIndex in 0..<dataSource.numberOfColumns {
        let columnLabel = dataSource.label(forColumn: columnIndex)
        let columnHeader = " \(columnLabel) |"
        headerRow += columnHeader
        
        columnWidths.append(columnHeader.count)
    }
    
    print(headerRow)
    
    for rowIndex in 0..<dataSource.numberOfRow {
        var output = "|"
        for rowColumnIndex in 0..<dataSource.numberOfColumns {
            let item = dataSource.itemForRow(row: rowIndex, column: rowColumnIndex)
            
            //MARK: FIRST CHALLENGE PROTOCOL CHALLENGE
            let paddingNeeded = columnWidths[rowColumnIndex] /*- item.count - 2*/ // solution1
            let padding = repeatElement(" ", count: paddingNeeded).joined(separator: "")
            
            output += " \(item)\(padding)|"
        }
        print(output)
    }
}



printTable(department)


// MARK: First Challenge - Extension Challenges
extension Department : CustomStringConvertible {
    public var description: String {
        return "Department Name: \(name)\nEmployees: \(people.count)"
    }
}
print(department)

//



struct School: TabularDataSource {
    var numberOfRow: Int { 10 }
    
    var numberOfColumns: Int { 2 }
    
    func label(forColumn column: Int) -> String {
        if column < 1 {
            return "Column A"
        } else {
            return "Column B"
        }
    }
    
    func itemForRow(row: Int, column: Int) -> String {
        return "test"
    }
    
    
}

let school = School()
//
//printTable(school)
//let tabularDeparment = department as TabularDataSource
////let optionalDepartment = school is TabularDataSource
//department as Department


//MARK: Second Challenge
//Create a new type, `BookCollection`, that conforms to `TabularDataSource`.
//Calling printTable(_:) on a book collection should show a table of books with columns for _titles_, _authors_, and _average reviews_.

struct Book {
    let title: String
    let author: String
    let average_review: Int
}


struct BookCollection: TabularDataSource {
    var numberOfRow: Int { books.count }
    
    var numberOfColumns: Int { 3 }
    
    func label(forColumn column: Int) -> String {
        let label: String
        
        switch column {
        case 0: label = "Title"
        case 1: label = "Author"
        case 2: label = "Average review"
        default: fatalError("A book collection should only have 3 columns")
        }
        
        return label
    }
    
    func itemForRow(row: Int, column: Int) -> String {
        let book = books[row]
        let item: String
        
        switch column {
        case 0: item = book.title
        case 1: item = book.author
        case 2: item = "\(book.average_review)"
        default: fatalError("A book collection should only have 3 columns")
        }
        
        return item
    }
    let title: String
    var books: [Book] = []
    init(title: String) {
        self.title = title
    }
    mutating func add(_ book: Book) {
        books.append(book)
    }
    
}

var bookCollection = BookCollection(title: "My library")
bookCollection.add(Book(title: "Almendra", author: "Won-Pyung-Sohn", average_review: 10))
bookCollection.add(Book(title: "Viviendo su voluntad", author: "Sebastián Franz", average_review: 10))
bookCollection.add(Book(title: "Harry Potter y la piedra filosofal", author: "JK Rowling", average_review: 10))

printTable(bookCollection)



