//: [Previous](@previous)

import Foundation

//MARK: Ninth challenge
//Given an array of people, find the youngest, the oldest and the difference in age
//between them, and return their respective ages and the age difference.
struct Person {
let name: String
let age: Int
}

func findAgeDifference(for people: [Person]) -> (oldest: Int, youngest:Int, ageDifference:Int){
    let ages = people.map { $0.age }
    guard let maxAge = ages.max(),
          let minAge = ages.min()
    else { return (0,0,0) }
    return (maxAge, minAge, maxAge - minAge)
}

let son = Person(name: "Juan", age: 19)
let daughter = Person(name: "Maria", age: 12)
let mother = Person(name: "Benita", age: 60)
let father = Person(name: "Camilo", age: 58)
let family = [daughter, son, mother, daughter]
//Example:
findAgeDifference(for: family) // (oldest: 60, youngest: 12, ageDifference: 48)







//: [Next](@next)
