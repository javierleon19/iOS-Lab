//: [Previous](@previous)

import Foundation

//MARK: Fifth challenge
//Make a function that receives an array of optional strings and returns all the non-nil
//values in a new array. If all values are nil, return a message: "All values are empty”.
//Example:
//let texts: [String?] = ["Hello", nil, "World"]
//filterOptionals(texts) // ["Hello", “World"]

func filterOptionals(_ texts: [String?]) -> [String] {
    var result: [String] = []
    for text in texts {
        if let text {
            result.append(text)
        }
    }
    return result
}

let texts: [String?] = ["Hello", nil, "World"]
filterOptionals(texts) // ["Hello", “World"]

//: [Next](@next)
