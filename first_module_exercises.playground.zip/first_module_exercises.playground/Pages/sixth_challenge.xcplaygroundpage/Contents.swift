//: [Previous](@previous)

import Foundation

//MARK: Sixth challenge
//Given an optional string, print "It's empty! You ripped me off!" when it's nil, "Thanks for
//my cat Schrödinger!" if input is "😺 " and "This ain't a cat!" when none of the others
//Example:
//receiveBox(with: “😺 ") // "Thanks for my cat Schrödinger!"
//receiveBox(with: nil) // "It's empty! You ripped me off!"
//receiveBox(with: “lol") // "This ain't a cat!”

func receiveBox(with content: String?) {
    if content == nil {
        print("It's empty! You ripped me off!")
    } else if content == "😺" {
        print("Thanks for my cat Schrödinger!")
    } else {
        print("This ain't a cat!") }
}

receiveBox(with: "😺") // "Thanks for my cat Schrödinger!"
receiveBox(with: nil) // "It's empty! You ripped me off!"
receiveBox(with: "lol") // "This ain't a cat!”






//: [Next](@next)
