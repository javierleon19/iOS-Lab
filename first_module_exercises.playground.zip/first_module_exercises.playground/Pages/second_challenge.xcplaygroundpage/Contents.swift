//: [Previous](@previous)

import Foundation

//MARK: Second challenge
//Create a function that receives an array of integers and returns a dictionary with the
//count of positive, negative and zero values.
//Example:
//checkNumbers([-3, 0, 2, 5, -1]) // ["positives": 2, "negatives": 2, “zeros":1]


func checkNumbers(_ numbers: [Int]) -> [String: Int] {
    var positives: Int = 0
    var negatives: Int = 0
    var zeros: Int = 0
    for number in numbers {
        if number > 0 {
            positives += 1
        } else if number < 0 {
            negatives += 1
        } else {
            zeros += 1
        }
    }
    return ["positives": positives, "negatives": negatives, "zeros": zeros]
}

checkNumbers([-3, 0, 2, 5, -1])



//: [Next](@next)
