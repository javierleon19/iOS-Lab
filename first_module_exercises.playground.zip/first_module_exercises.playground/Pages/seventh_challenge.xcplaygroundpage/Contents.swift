//: [Previous](@previous)

import Foundation

//MARK: Seventh challenge
//Create a function that simulates a simple bank account system.
//Requirements:
//Define a struct BankAccount with:
//•
//owner: String
//•
//balance: Double
//Add methods:
//•
//deposit(amount: Double) → increases the balance.
//•
//withdraw(amount: Double) → decreases the balance, but only if there are
//sufficient funds. Otherwise, print "Insufficient funds”.
//•
//transfer(amount: Double, to otherAccount: inout BankAccount) → transfers
//money to another account if balance is enough.
//Example:
//var account1 = BankAccount(owner: "Alice", balance: 1000)
//var account2 = BankAccount(owner: "Bob", balance: 500)
//account1.withdraw(amount: 200) // balance = 800
//account1.transfer(amount: 300, to: &account2)
// account1.balance = 500
//account2.balance = 800

struct bankAccount {
    var owner: String
    var balance: Double
    
    mutating func deposit(amount: Double) {
        balance += amount
    }
    
    mutating func withdraw(amount: Double) {
        guard balance >= amount else {
            print("insufficient funds")
            return
        }
        balance -= amount
    }
    
    mutating func transfer(amount: Double, to otherAccount: inout bankAccount) {
        guard balance >= amount else {
            print("insufficient funds")
            return
        }
        balance -= amount
        otherAccount.deposit(amount: amount)
    }
}

var account1 = bankAccount(owner: "Alice", balance: 1000)
var account2 = bankAccount(owner: "Bob", balance: 500)

account1.withdraw(amount: 200)
account1.transfer(amount: 300, to: &account2)

print("account1 balance: \(account1.balance)")
print("account2 balance: \(account2.balance)")




//: [Next](@next)
