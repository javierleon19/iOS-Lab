//: [Previous](@previous)

import Foundation

//MARK: First challenge
//Create a function that receives an enumerator as a parameter with the following options: .suma, .resta, .multiplicacion, .division and an array of numbers. Return
//the result after applying the selected operation to all numbers. Handle division by zero
//with Result or throws.
//Example:
//operation(.addition, numbers: [1,2,3,4]) // 10
//operation(.division, numbers: [20, 5, 0]) // error: division by zero
enum Operation {
    case addition
}

func operation(_ operation: String, numbers: [Int]) -> Int {
    var result: Int = 0
    switch operation {
    case "addition":
        for number in numbers {
            result += number
        }
    case "subtraction":
        for number in numbers {
             result -= number
        }
    case "multiplication":
        result += 1
        for number in numbers {
            result *= number
        }
    case "division":
        result += 1
        for number in numbers {
            if number == 0 {
                print("Error: division by zero")
            } else {
                result /= number
            }
        }
        
    default : break
    }
    return result
}

let numbers: [Int] = [1, 2, 3, 4]
print(operation("addition", numbers: numbers))
print(operation("subtraction", numbers: numbers))
print(operation("multiplication", numbers: numbers))
print(operation("division", numbers: numbers))
print(operation("division", numbers: [20, 5, 0]))




//: [Next](@next)
