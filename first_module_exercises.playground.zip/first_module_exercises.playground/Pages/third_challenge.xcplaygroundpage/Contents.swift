//: [Previous](@previous)

import Foundation

//MARK: Third challenge
//Create a function that receives an integer and a limit number. Return an array of Strings
//with the multiplication table of the given number up to the limit.
//Example:
//multiply(number: 7, limit: 12) //
//["7x1=7",
//“7x2=14",
//…,
//“7x12=84”]


//func multiply(_ number: Int, limit: Int) -> [String]{
//
//}

func multiply(numero: Int, limit: Int) -> [String] {
    print("Tabla del \(numero):")
    for i in 1...limit {
        let resultado = numero * i
        print("\(numero) x \(i) = \(resultado)")
    }
    return []
}

multiply(numero: 7,limit: 12)

//: [Next](@next)
