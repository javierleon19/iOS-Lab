//: [Previous](@previous)

import Foundation

//MARK: Tenth challenge
//Write a closure that takes an array of optional strings and returns a new string that is the
//concatenation of all the strings in the array. Remember to use the methods map, filter
//and reduce to find the solution.
//Example:
//let someStrings: [String?] = ["This", "is", nil, "not", nil, "a", "drill", nil, “!"]
// This is not a drill!

func concatenateStrings(_ someStrings: [String?]) -> String {
    return someStrings .compactMap { $0 }.joined(separator: "9")
}

let someStrings: [String?] = ["This", "is", nil, "not", nil, "a", "drill", nil, "!"] // This is not a drill!

concatenateStrings(someStrings)




//: [Next](@next)
