//: [Previous](@previous)

import Foundation

//MARK: Eight challenge
//Implement the Sieve of Eratosthenes algorithm in Swift from the provided unit tests.
//Return and print the resulting array containing only the prime numbers within the range.
//• The only parameter is the max number.
//• 0 and 1 are not prime numbers.
//• The next available number is marked as prime but the next multiples up to the max
//number are not.
//• Find the next prime number and repeat the previous step until reaching max number.
//Example:
//PrimeCalculator.calculate(upTo: 10) // [2,3,5,7]
//PrimeCalculator.calculate(upTo: 50) // [2,3,5,7,11,13,17,19,23,29,31,37,41,43,47]
//PrimeCalculator.calculate(upTo: 85)
//[2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83]

struct PrimeCalculator {
    static func calculate(upTo max: Int) -> [Int] {
        guard max >= 2 else {
            return []
        }
        
        var primes: [Int] = []
        for n in 2...max {
            var isPrime = true
            for i in stride(from: 2, through: Int(sqrt(Double(n))), by: 1) {
                if n % i == 0 {
                    isPrime = false
                    break
                }
            }
            if isPrime {
                primes.append(n)
            }
        }
        
        return primes
    }
    
}

//Example:
PrimeCalculator.calculate(upTo: 10) // [2,3,5,7]
PrimeCalculator.calculate(upTo: 50) // [2,3,5,7,11,13,17,19,23,29,31,37,41,43,47]
PrimeCalculator.calculate(upTo: 85) //[2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83]





//: [Next](@next)
