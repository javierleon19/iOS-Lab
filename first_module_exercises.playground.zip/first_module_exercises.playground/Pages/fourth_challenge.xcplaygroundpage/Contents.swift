//: [Previous](@previous)

import Foundation

//MARK: Fourth challenge
//Make a function that receives a string that simulates a password and returns an enum
//PasswordStrength: .weak, .medium, .strong depending on rules: - Minimum 6
//characters - Contains a capital letter - Contains a number - Contains a point - Bonus:
//contains a special symbol (!, @, #, etc.).
//Example:
//checkPassword("Pass123.") // .medium
//checkPassword("Strong#Pass1.") // .strong

enum PasswordStrength {
    case weak, medium, strong
}


func checkPassword(_ password: String) -> PasswordStrength {
    let minuscula = password.count >= 6
    let mayuscula = password.contains { $0.isUppercase }
    let numero = password.contains { $0.isNumber }
    let punto = password.contains(".")
    let simbolos = password.contains { "!@#$%^&*".contains($0) }
    if minuscula && mayuscula && numero && punto && simbolos {
        return .strong
    } else if minuscula && mayuscula && numero && punto {
        
        
        return .medium
        
    } else {
        return .weak
    }
}

checkPassword("Pass123.") // .medium
checkPassword("Strong#Pass1.") // .strong
checkPassword("Holape9.")
//: [Next](@next)
